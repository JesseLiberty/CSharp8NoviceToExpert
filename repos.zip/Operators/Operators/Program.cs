﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            var x = 5;
            var y = 5;
            var z = 7;

            var a = x + 5 * z; // 40
            var b = (x + 5) * z;  //70

        }
    }
}
